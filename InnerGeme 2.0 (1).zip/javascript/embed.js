        fetch('/assets/icons/social/pinterest.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('pinterest').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/snapchat.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('snapchat').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/instagram.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('instagram').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
          
        fetch('/assets/icons/social/linkedin.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('linkedin').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/spotify.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('spotify').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/tiktok.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('tiktok').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/youtube.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('youtube').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));
        fetch('/assets/icons/social/x.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('x').innerHTML = data;
          })
          .catch(error => console.error('Error loading the SVG:', error));