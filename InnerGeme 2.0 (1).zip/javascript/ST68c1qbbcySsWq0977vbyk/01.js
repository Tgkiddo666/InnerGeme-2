  // JavaScript for toggling the content table
  document.querySelector('#toggle-table').addEventListener('click', function() {
    var contentTable = document.querySelector('#content-table');
    var bottomNav = document.querySelector('#bottom-nav');
    var closeButton = document.querySelector('#close-menu');
    var overlay = document.querySelector('#overlay');
    if (!contentTable.classList.contains('visible')) {
      contentTable.classList.add('visible');
      bottomNav.classList.add('no-radius');
      this.textContent = 'Back';
      closeButton.style.display = 'none';
      overlay.classList.add('visible');
    } else {
      contentTable.classList.remove('visible');
      bottomNav.classList.remove('no-radius');
      this.textContent = 'Table of Contents';
      closeButton.style.display = 'block';
      overlay.classList.remove('visible');
    }
  });

  // JavaScript for the close button functionality
  document.querySelector('#close-menu').addEventListener('click', function() {
    var bottomNav = document.querySelector('#bottom-nav');
    var openMenuButton = document.querySelector('#open-menu');
    bottomNav.classList.add('hidden');
    openMenuButton.style.display = 'flex';
  });

  // JavaScript for the close button inside content table
    // JavaScript for the open menu button functionality
  document.querySelector('#open-menu').addEventListener('click', function() {
    var bottomNav = document.querySelector('#bottom-nav');
    bottomNav.classList.remove('hidden');
    this.style.display = 'none';
  });

  // JavaScript for scrolling to the paragraph
  document.querySelectorAll('.content-table p').forEach(function(item) {
    item.addEventListener('click', function() {
      var targetId = this.getAttribute('data-target');
      var targetElement = document.querySelector(targetId);
      var contentTable = document.querySelector('#content-table');
      var bottomNav = document.querySelector('#bottom-nav');
      var overlay = document.querySelector('#overlay');
      if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth' });
        contentTable.classList.remove('visible');
        bottomNav.classList.remove('no-radius');
        document.querySelector('#toggle-table').textContent = 'Table of Contents';
        document.querySelector('#close-menu').style.display = 'block';
        overlay.classList.remove('visible');
      }
    });
  });

  // Customizable share text and link
  var shareText = "Check out this amazing content!";
  var shareLink = window.location.href;

  // JavaScript for Share button functionality
  function shareContent() {
    if (navigator.share) {
      navigator.share({
        title: 'Web Page Title',
        text: shareText,
        url: shareLink
      }).then(() => {
        console.log('Thanks for sharing!');
      })
      .catch(console.error);
    } else {
      alert('Web share not supported on this browser.');
    }
  }

  // Attach the shareContent function to the Share button
  document.querySelector('#share').addEventListener('click', shareContent);
  
  
document.addEventListener('DOMContentLoaded', function() {
  const dropdown1 = document.getElementById('dropdown-content1');
  dropdown1.style.display = 'none';

  const upFacingSvg1 = document.getElementById('up-facing1');
  const downFacingSvg1 = document.getElementById('down-facing1');
  upFacingSvg1.style.display = 'none';
  downFacingSvg1.style.display = 'block';

  const hamburgerIcon1 = document.querySelector('.hamburger-icon1');
  hamburgerIcon1.addEventListener('click', toggleMenu1);

  document.addEventListener('click', function(event) {
    if (!event.target.matches('.hamburger-icon1') && !event.target.closest('#dropdown-content1')) {
      dropdown1.style.display = 'none';
      upFacingSvg1.style.display = 'none';
      downFacingSvg1.style.display = 'block';
    }
  });
});

function toggleMenu1(event) {
  event.stopPropagation();
  const dropdown1 = document.getElementById('dropdown-content1');
  const upFacingSvg1 = document.getElementById('up-facing1');
  const downFacingSvg1 = document.getElementById('down-facing1');
  
  if (dropdown1.style.display === 'block') {
    dropdown1.style.display = 'none';
    upFacingSvg1.style.display = 'none';
    downFacingSvg1.style.display = 'block';
  } else {
    dropdown1.style.display = 'block';
    upFacingSvg1.style.display = 'block';
    downFacingSvg1.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  const dropdown2 = document.getElementById('dropdown-content2');
  dropdown2.style.display = 'none';

  const upFacingSvg2 = document.getElementById('up-facing2');
  const downFacingSvg2 = document.getElementById('down-facing2');
  upFacingSvg2.style.display = 'none';
  downFacingSvg2.style.display = 'block';

  const hamburgerIcon2 = document.querySelector('.hamburger-icon2');
  hamburgerIcon2.addEventListener('click', toggleMenu2);

  document.addEventListener('click', function(event) {
    if (!event.target.matches('.hamburger-icon2') && !event.target.closest('#dropdown-content2')) {
      dropdown2.style.display = 'none';
      upFacingSvg2.style.display = 'none';
      downFacingSvg2.style.display = 'block';
    }
  });
});

function toggleMenu2(event) {
  event.stopPropagation();
  const dropdown2 = document.getElementById('dropdown-content2');
  const upFacingSvg2 = document.getElementById('up-facing2');
  const downFacingSvg2 = document.getElementById('down-facing2');
  
  if (dropdown2.style.display === 'block') {
    dropdown2.style.display = 'none';
    upFacingSvg2.style.display = 'none';
    downFacingSvg2.style.display = 'block';
  } else {
    dropdown2.style.display = 'block';
    upFacingSvg2.style.display = 'block';
    downFacingSvg2.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  const dropdown3 = document.getElementById('dropdown-content3');
  dropdown3.style.display = 'none';

  const upFacingSvg3 = document.getElementById('up-facing3');
  const downFacingSvg3 = document.getElementById('down-facing3');
  upFacingSvg3.style.display = 'none';
  downFacingSvg3.style.display = 'block';

  const hamburgerIcon3 = document.querySelector('.hamburger-icon3');
  hamburgerIcon3.addEventListener('click', toggleMenu3);

  document.addEventListener('click', function(event) {
    if (!event.target.matches('.hamburger-icon3') && !event.target.closest('#dropdown-content3')) {
      dropdown3.style.display = 'none';
      upFacingSvg3.style.display = 'none';
      downFacingSvg3.style.display = 'block';
    }
  });
});

function toggleMenu3(event) {
  event.stopPropagation();
  const dropdown3 = document.getElementById('dropdown-content3');
  const upFacingSvg3 = document.getElementById('up-facing3');
  const downFacingSvg3 = document.getElementById('down-facing3');
  
  if (dropdown3.style.display === 'block') {
    dropdown3.style.display = 'none';
    upFacingSvg3.style.display = 'none';
    downFacingSvg3.style.display = 'block';
  } else {
    dropdown3.style.display = 'block';
    upFacingSvg3.style.display = 'block';
    downFacingSvg3.style.display = 'none';
  }
}

// Ensure the dropdown is hidden on page load
document.addEventListener('DOMContentLoaded', function() {
  const dropdown = document.getElementById('dropdown-content');
  dropdown.style.display = 'none';

  // Initially hide the up-facing SVG and show the down-facing SVG
  const upFacingSvg = document.getElementById('up-facing4');
  const downFacingSvg = document.getElementById('down-facing4');
  upFacingSvg.style.display = 'none';
  downFacingSvg.style.display = 'block';

  // Attach click event to the hamburger icon
  const hamburgerIcon = document.querySelector('.hamburger-icon');
  hamburgerIcon.addEventListener('click', toggleMenu);

  // Attach event listener to close the menu when clicking outside
  document.addEventListener('click', function(event) {
    if (!event.target.matches('.hamburger-icon') && !event.target.closest('#dropdown-content')) {
      dropdown.style.display = 'none';
      upFacingSvg.style.display = 'none';
      downFacingSvg.style.display = 'block';
    }
  });
});

// Function to toggle menu visibility
function toggleMenu(event) {
  event.stopPropagation(); // Prevent the click from bubbling up to the document
  const dropdown = document.getElementById('dropdown-content');
  const upFacingSvg = document.getElementById('up-facing4');
  const downFacingSvg = document.getElementById('down-facing4');

  if (dropdown.style.display === 'block') {
    dropdown.style.display = 'none';
    upFacingSvg.style.display = 'none';
    downFacingSvg.style.display = 'block';
  } else {
    dropdown.style.display = 'block';
    upFacingSvg.style.display = 'block';
    downFacingSvg.style.display = 'none';
  }
}

        const openMenuBtn = document.getElementById('open-menu-btn');
        const closeMenuBtn = document.getElementById('close-menu-btn');
        const customMenu = document.getElementById('custom-menu');

        openMenuBtn.addEventListener('click', () => {
            customMenu.style.display = 'flex';
        });

        closeMenuBtn.addEventListener('click', () => {
            customMenu.style.display = 'none';
        });