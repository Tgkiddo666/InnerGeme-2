        fetch('/assets/icons/logo.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('logo-container').innerHTML = data;
            document.querySelector('#logo-container svg').id = 'logo'; // Add an ID for styling
          })
          .catch(error => console.error('Error loading the SVG:', error));
          
        fetch('/assets/icons/logo.svg')
          .then(response => response.text())
          .then(data => {
            document.getElementById('logo-container-white').innerHTML = data;
            document.querySelector('#logo-container svg').id = 'logo-white'; // Add an ID for styling
          })
          .catch(error => console.error('Error loading the SVG:', error));